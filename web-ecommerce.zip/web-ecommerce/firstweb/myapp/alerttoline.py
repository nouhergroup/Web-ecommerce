#alerttoline.py
# pip install songline
from songline import Sendline
token = '9xfgRuo7AKdrlu3EguavIzKTXf55niOmkWbw6jswRDr'
messenger = Sendline(token)

# test send
#messenger.sendtext('สวัสดีจ้าาาา ลุงสั่งออร์เดอร์ 1000 รายการ')
#messenger.sticker(14,1,'ลูกค้าสั่งมา 10000 บาท')
#messenger.sendimage('https://image.makewebeasy.net/makeweb/0/xp369fBVd/DefaultData/Durian_K__1_.jpg')


